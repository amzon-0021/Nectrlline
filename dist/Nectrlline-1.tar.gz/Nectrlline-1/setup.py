from setuptools import setup

setup(
    name='Nectrlline',
    version='1',
    description='Awesome library',
    url='https://github.com/whatever/whatever',
    author='amzon_0021',
    author_email='riimuww@gmail.com',
    license='MIT',
    keywords='sample setuptools development',
    packages=[
        "line.py",
    ],
    classifiers=[
        'Programming Language :: Python :: 3.7 :: amzon',
    ],
)
